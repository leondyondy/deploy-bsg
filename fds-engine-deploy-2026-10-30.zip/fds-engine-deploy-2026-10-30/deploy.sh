#!/usr/bin/env bash
# Offline deploy of fds-rule-engine-grpc on the target server (SIT/UAT), the
# docker-run equivalent of the Jenkinsfile's Deploy stage. Images arrive as a
# `docker save` tarball (no registry, no pull); secrets come from env files on
# the server, never from the image.
#
# Usage (on the server, as a docker-group admin):
#   scripts/deploy.sh load <tarball.tar.gz>   # verify .sha256 next to it, docker load
#   scripts/deploy.sh migrate [--dry-run] [--allow-destructive]
#   scripts/deploy.sh deploy <tag>            # e.g. 1.0.0 or sit
#   scripts/deploy.sh rollback                # back to the image tagged :previous
#   scripts/deploy.sh status
#
# Environment (override as needed):
#   API_ENV_FILE      /opt/fds/api.env        runtime config + secrets (chmod 600)
#   MIGRATE_ENV_FILE  /opt/fds/migrate.env    DATABASE_URL/QUESTDB_URL for migrations
#   TLS_CERT_DIR      /etc/fds-rule-engine/certs   server.crt, server.key, ca.crt
#   DOCKER_NET        fds-net                 network shared with the redis container
#   BIND_ADDR         127.0.0.1               host address the ports are published on;
#                                              keep loopback while nginx fronts the API
#   MEMORY_LIMIT      2g                      container memory cap
#
# The migrate image runs scripts/migrate.sh; run `migrate --dry-run` first and
# review what it would apply/skip before a real run.

set -euo pipefail

IMAGE=fds-rule-engine-grpc
MIGRATE_IMAGE=fds-rule-engine-grpc-migrate
CONTAINER=fds-rule-engine-grpc
DATA_VOLUME=fds-api-data

API_ENV_FILE="${API_ENV_FILE:-/opt/fds/api.env}"
MIGRATE_ENV_FILE="${MIGRATE_ENV_FILE:-/opt/fds/migrate.env}"
TLS_CERT_DIR="${TLS_CERT_DIR:-/etc/fds-rule-engine/certs}"
DOCKER_NET="${DOCKER_NET:-fds-net}"
BIND_ADDR="${BIND_ADDR:-127.0.0.1}"
MEMORY_LIMIT="${MEMORY_LIMIT:-2g}"

die() { echo "error: $*" >&2; exit 1; }

# require_env_file <file> -- exists, and readable by its owner only (it holds
# passwords; `docker inspect` exposure is limited by docker-group membership).
require_env_file() {
  local f="$1"
  [[ -r "$f" ]] || die "$f is missing or unreadable"
  local mode
  mode="$(stat -c '%a' "$f")"
  [[ "$mode" =~ ^[46]00$ ]] || die "$f has mode $mode; chmod 600 it first"
}

require_image() {
  docker image inspect "$1" >/dev/null 2>&1 || die "image $1 not loaded; run: $0 load <tarball>"
}

cmd_load() {
  local tarball="${1:-}"
  [[ -f "$tarball" ]] || die "usage: $0 load <tarball.tar.gz>"
  local sum="${tarball%.tar.gz}.sha256"
  [[ -f "$sum" ]] || die "checksum file $sum not found next to the tarball"
  (cd "$(dirname "$tarball")" && sha256sum -c "$(basename "$sum")") || die "checksum mismatch -- do not load"
  gunzip -c "$tarball" | docker load
}

cmd_migrate() {
  require_env_file "$MIGRATE_ENV_FILE"
  local tag="${MIGRATE_TAG:-sit}"
  require_image "$MIGRATE_IMAGE:$tag"
  echo "== migrating with $MIGRATE_IMAGE:$tag (flags: ${*:-none}) =="
  docker run --rm --env-file "$MIGRATE_ENV_FILE" "$MIGRATE_IMAGE:$tag" all up "$@"
}

# run_container <image> -- (re)creates the API container from <image>.
run_container() {
  local image="$1"

  # Fail before touching the running container if anything it needs is missing.
  require_env_file "$API_ENV_FILE"
  require_image "$image"
  for f in server.crt server.key ca.crt; do
    [[ -r "$TLS_CERT_DIR/$f" ]] || die "mTLS file $TLS_CERT_DIR/$f is missing or unreadable"
  done
  docker network inspect "$DOCKER_NET" >/dev/null 2>&1 || docker network create "$DOCKER_NET" >/dev/null

  docker stop "$CONTAINER" >/dev/null 2>&1 || true
  docker rm "$CONTAINER" >/dev/null 2>&1 || true

  docker run -d \
    --name "$CONTAINER" \
    --restart unless-stopped \
    --network "$DOCKER_NET" \
    -p "$BIND_ADDR:50051:50051" \
    -p "$BIND_ADDR:8081:8081" \
    --memory "$MEMORY_LIMIT" \
    --log-driver json-file --log-opt max-size=50m --log-opt max-file=5 \
    --env-file "$API_ENV_FILE" \
    -e TLS_CERT_FILE=/certs/server.crt \
    -e TLS_KEY_FILE=/certs/server.key \
    -e TLS_CA_FILE=/certs/ca.crt \
    -e DECISION_PG_SPILL_FILE=/data/decision_pg_deadletter.jsonl \
    -e CASES_SPILL_FILE=/data/cases_deadletter.jsonl \
    -v "$TLS_CERT_DIR:/certs:ro" \
    -v "$DATA_VOLUME:/data" \
    "$image" >/dev/null

  wait_healthy
}

# wait_healthy -- the server exits on any startup failure (DB unreachable,
# bad certs, ...), so "still running with no restarts after 15s and logged
# mTLS enabled" is a sound startup check. Real traffic checks need a client
# cert (see docs/MTLS-SETUP.md).
wait_healthy() {
  sleep 15
  local running restarts
  running="$(docker inspect -f '{{.State.Running}}' "$CONTAINER")"
  restarts="$(docker inspect -f '{{.RestartCount}}' "$CONTAINER")"
  if [[ "$running" != true || "$restarts" != 0 ]]; then
    docker logs --tail 30 "$CONTAINER" >&2
    die "container is not healthy (running=$running restarts=$restarts); consider: $0 rollback"
  fi
  docker logs "$CONTAINER" 2>&1 | grep -q "mTLS enabled" || die "container is running but never logged 'mTLS enabled'"
  echo "== $CONTAINER is up: $(docker inspect -f '{{.Config.Image}}' "$CONTAINER") =="
}

cmd_deploy() {
  local tag="${1:-}"
  [[ -n "$tag" ]] || die "usage: $0 deploy <tag>"

  # Keep the currently running image as :previous so rollback needs no tarball.
  local current_id
  current_id="$(docker inspect -f '{{.Image}}' "$CONTAINER" 2>/dev/null || true)"
  if [[ -n "$current_id" ]]; then
    docker tag "$current_id" "$IMAGE:previous"
    echo "== saved running image as $IMAGE:previous =="
  fi

  run_container "$IMAGE:$tag"
}

cmd_rollback() {
  require_image "$IMAGE:previous"
  echo "== rolling back to $IMAGE:previous (schema changes are NOT reverted; restore the DB backup if needed) =="
  run_container "$IMAGE:previous"
}

cmd_status() {
  docker ps -a --filter "name=^${CONTAINER}$" --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}'
  docker images "$IMAGE" --format 'table {{.Repository}}:{{.Tag}}\t{{.ID}}\t{{.CreatedSince}}'
  docker logs --tail 10 "$CONTAINER" 2>&1 || true
}

case "${1:-}" in
  load)     shift; cmd_load "$@" ;;
  migrate)  shift; cmd_migrate "$@" ;;
  deploy)   shift; cmd_deploy "$@" ;;
  rollback) shift; cmd_rollback ;;
  status)   shift; cmd_status ;;
  *) sed -n '2,/^$/p' "$0" | sed 's/^# \{0,1\}//'; exit 1 ;;
esac
